package com.example.wings2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class chart extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
    RadioGroup rg;
    ImageView i1;
   int []images={R.drawable.ab,R.drawable.ab1,R.drawable.a,R.drawable.a1,R.drawable.b,R.drawable.b1,R.drawable.o,R.drawable.o1};
    RadioButton r1,r2,r3,r4,r5,r6,r7,r8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        rg=findViewById(R.id.rg);
        r1=findViewById(R.id.radioButton);
        r2=findViewById(R.id.radioButton2);
        r3=findViewById(R.id.radioButton3);
        r4=findViewById(R.id.radioButton4);
        r5=findViewById(R.id.radioButton5);
        r6=findViewById(R.id.radioButton6);
        r7=findViewById(R.id.radioButton7);
        r8=findViewById(R.id.radioButton8);
        rg.setOnCheckedChangeListener(this);
        i1=findViewById(R.id.imageView1);
        i1.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        i1.setVisibility(View.VISIBLE);
        switch(i)
        {
            case R.id.radioButton:{
                i1.setImageResource(images[0]);
                break;
            }
            case R.id.radioButton2:{
                i1.setImageResource(images[1]);
                break;
            }
            case R.id.radioButton3:{
                i1.setImageResource(images[2]);

                break;
            }
            case R.id.radioButton4:{
                i1.setImageResource(images[3]);

                break;
            }
            case R.id.radioButton5:{
                i1.setImageResource(images[4]);

                break;
            }
            case R.id.radioButton6:{
                i1.setImageResource(images[5]);
                break;
            }
            case R.id.radioButton7:{
                i1.setImageResource(images[6]);

                break;
            }
            case R.id.radioButton8:{
                i1.setImageResource(images[7]);

                break;
            }
        }
    }
}

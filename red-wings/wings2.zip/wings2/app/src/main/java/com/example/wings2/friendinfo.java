package com.example.wings2;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class friendinfo extends AppCompatActivity {
    Spinner s1;
    DatabaseHandler db;
    TextView t22,t23,t24;
    Intent i1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friendinfo);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        i1=getIntent();
        s1 = findViewById(R.id.spinner4);
        t22 = findViewById(R.id.textView22);
        t23 = findViewById(R.id.textView23);
        t24 = findViewById(R.id.textView24);
        FloatingActionButton fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View view) {
                                       Intent i = new Intent(Intent.ACTION_DIAL);
                                       i.setData(Uri.parse("tel:"+t24.getText().toString()));
                                       i.setAction(Intent.ACTION_CALL);
                                       // i.putExtra(Intent.EXTRA_TEXT,"9599355184");
                                       //i.setType("CALL_PHONE");
                                       startActivity(i);
                                   }
                               }
        );
        db = new DatabaseHandler(this);
        int size = db.getUserCount();
        String[] mylist = new String[size];
        int i = 0;
        List<User> user = db.getAllUsers();
        for (User cn : user) {
                mylist[i] = cn.getName();
                i++;

        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mylist);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s1.setAdapter(adapter);
        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                         @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                                         @Override
                                         public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                             String a = ((TextView) view).getText().toString();
                                             Log.d("friend_info",a);
                                             User user = db.getUser(a);
                                             t22.setText(user.getName());
                                             t24.setText(user.getContact());
                                             t23.setText(user.get_blood());
                                         }
                                         public void onNothingSelected(AdapterView<?> adapterView) {

                                         }
                                     }
        );
    }}

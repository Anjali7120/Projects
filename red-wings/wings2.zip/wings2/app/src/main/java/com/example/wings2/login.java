package com.example.wings2;



import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static android.content.Intent.EXTRA_REFERRER_NAME;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

public class login extends AppCompatActivity implements View.OnClickListener {
    Button b1,b2;
    EditText e1,e3;
    User user;
    DatabaseHandler d=new DatabaseHandler(this);
    Context myContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        e1=(EditText)findViewById(R.id.editText);
        e3=(EditText)findViewById(R.id.editText3);
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onClick(View view) {
        if(view==b1)
        {

            user=d.getUser(e1.getText().toString());
            Log.d("sakshi",user.get_password());
            Log.d("sakshifgd4",user.getName());
            if((e3.getText().toString()).equals(user.get_password())==TRUE) {

                Log.d("login","login");
                Intent i = new Intent(this, home.class);
                i.putExtra(Intent.EXTRA_TEXT,e1.getText().toString());
                i.putExtra(Intent.EXTRA_REFERRER,e3.getText().toString());
                i.putExtra(Intent.EXTRA_REFERRER_NAME,user.getContact());
                i.putExtra(Intent.EXTRA_KEY_EVENT,user.get_blood());
                i.putExtra(Intent.EXTRA_PACKAGE_NAME, "login");
                d.close();
                startActivity(i);

                finish();
            }
            else
            {
                Toast.makeText(this,"Incorrect password or username",Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Intent i=new Intent(this,signup.class);
           d.close();
            startActivity(i);
            finish();
        }

    }
}


class DatabaseHandler extends SQLiteOpenHelper {
    //SQLiteDatabase sq=null;
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "users";

    // Contacts table name
    private static final String TABLE_NAME = "user_list";

    // Contacts Table Columns names
    private static final String CONTACT = "contact_no";
    private static final String USER_NAME = "name";
    private static final String B_GRP = "blood_group";
    private static final String PASSWORD = "password_new";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_USER_TABLE = "CREATE TABLE user_list(name TEXT PRIMARY KEY,contact_no TEXT,password_new TEXT,blood_group TEXT)";
        db.execSQL(CREATE_USER_TABLE);
        Log.d("onCreate","createTable");

        String insert_table1= "INSERT INTO user_list (name, contact_no, password_new, blood_group)\n" +
                "        VALUES ('sakshi','9599355184',  'O-', 'sjain');";

        String insert_table2= "INSERT INTO user_list (name, contact_no, password_new, blood_group)\n" +
                "        VALUES ('anjali','8851471064', 'A+', 'anj');";

        String insert_table3= "INSERT INTO user_list (name, contact_no, password_new, blood_group)\n" +
                "        VALUES ('vaishnavi','9027242238',  'AB+', 'vaish');";


        db.execSQL(insert_table1);
        db.execSQL(insert_table2);
        db.execSQL(insert_table3);
        Log.d("insert","row");
        String selectQuery = "SELECT  * FROM " + TABLE_NAME;

        // SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        Log.d("jkl",String.valueOf(cursor.getCount()));
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                //Contact contact = new Contact();
                Log.d("vanja0", cursor.getString(0));
                Log.d("vanja1", cursor.getString(1));
                Log.d("vanja2", cursor.getString(2));
                Log.d("vanja3", cursor.getString(3));
            } while (cursor.moveToNext());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        Log.d("onUpgrade","upgrading...");
        // Create tables again
        onCreate(db);
    }

    // Adding new user



    // Adding new user
    void addUser(User user) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(USER_NAME,user.getName());
        cv.put(PASSWORD,user.get_password());
        cv.put(CONTACT,user.getContact());
        cv.put(B_GRP,user.get_blood());
        db.insert(TABLE_NAME,null,cv);
         db.close(); // Closing database connection
    }
    // Getting info about particular user
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    User getUser(String name) {
        SQLiteDatabase db=this.getReadableDatabase();
        User user1=new User("sakshi","9599355184","O-","sjain");
        Cursor cursor1 = db.query(TABLE_NAME, new String[]{CONTACT, USER_NAME, B_GRP, PASSWORD}, USER_NAME + "=?",
                new String[]{name}, null, null, null, null);
        if (cursor1 != null)
            cursor1.moveToFirst();
        // SQLiteDatabase sqLiteDatabase = null;
        String selectQuery = "SELECT  * FROM " + TABLE_NAME;
        //db.execSQL(selectQuery);
        cursor1 = db.rawQuery(selectQuery, null);
        if (cursor1.moveToFirst()) {
            do {
                if((cursor1.getString(0)).equals(name))
                {
                    user1.setName(cursor1.getString(0));
                    user1.setContact(cursor1.getString(1));
                    user1.set_blood(cursor1.getString(2));
                    user1.set_password(cursor1.getString(3));
                    break;
                }
                Log.d("anja0", cursor1.getString(0));
                Log.d("anja1", cursor1.getString(1));
                Log.d("anja2", cursor1.getString(2));
                Log.d("anja3", cursor1.getString(3));
            }while (cursor1.moveToNext());
        }
        cursor1.moveToFirst();
        return user1;
    }

    // Getting info abt all users
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<User>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getReadableDatabase();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setName(cursor.getString(0));
                user.setContact(cursor.getString(1));
                user.set_blood(cursor.getString(2));
                user.set_password(cursor.getString(3));
                // Adding contact to list
                userList.add(user);
            } while (cursor.moveToNext());
        }

        // return multiple users
        return userList;
    }

    // Updating user info
    public void updateUser(String s1, String s2, String s3, String s4) {
        SQLiteDatabase db = this.getWritableDatabase();
       /* String insert_table3= "UPDATE user_list\n SET name= "+s1+", contact_no= "+s2+", password_new = "+s3+", blood_group= "+s4+"\n WHERE "+USER_NAME + " = "+ s1;
        db.execSQL(insert_table3);
        db.close();*/
      ContentValues values = new ContentValues();
        values.put(CONTACT, s4);
        values.put(B_GRP, s3);
        values.put(PASSWORD, s2);
        // updating row
        db.update(TABLE_NAME, values, USER_NAME + " = ?",new String[]{s1});

    }


    // Getting total number of users
    public int getUserCount() {
        String countQuery = "SELECT  * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        return cursor.getCount();
    }

    // Getting info abt particular users
    public List<User> getP_Users(String s1) {
        List<User> userList = new ArrayList<User>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_NAME + " WHERE " + B_GRP + "=?" + new String[]{s1};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setContact(cursor.getString(0));
                user.setName(cursor.getString(1));
                user.set_blood(cursor.getString(2));
                user.set_password(cursor.getString(3));
                // Adding contact to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        return userList;
    }

    // Getting particular number of users
    public int getP_UserCount(String s1) {
        String countQuery = "SELECT  * FROM " + TABLE_NAME + " WHERE " + B_GRP + "=?" + new String[]{s1};
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        return cursor.getCount();
    }
}

class User {

    //private variables
    private String _contact;
    private String _name;
    private String _blood;
    private String _password_new;

    // Empty constructor
    public User(){
        this._contact="910";
        this._blood="A";
        this._name="anjali";
        this._password_new="vashu";
    }
    // constructor
    public User(String name, String contact, String blood, String password){
        this._contact = contact;
        this._name = name;
        this._blood = blood;
        this._password_new = password;
    }
    // getting contact
    public String getContact(){
        return this._contact;
    }

    // setting contact
    public void setContact(String contact){
        this._contact = contact;
    }

    // getting name
    public String getName(){
        return this._name;
    }

    // setting name
    public void setName(String name){
        this._name = name;
    }

    // getting blood group
    public String get_blood(){
        return this._blood;
    }

    // setting blood group
    public void set_blood(String blood){
        this._blood = blood;
    }
    // getting password
    public String get_password(){
        return this._password_new;
    }

    // setting password
    public void set_password(String password){
        this._password_new = password;
    }

}



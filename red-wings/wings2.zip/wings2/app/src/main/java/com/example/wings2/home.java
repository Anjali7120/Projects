package com.example.wings2;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class home extends AppCompatActivity {
    AlertDialog.Builder adb;
    TextView t9,t10,t11;
    Intent i1;
    User user;
    DatabaseHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        db=new DatabaseHandler(this);
        Toast.makeText(this,"login successfully",Toast.LENGTH_SHORT).show();
        t9=findViewById(R.id.textView9);
        t10=findViewById(R.id.textView10);
        t11=(TextView) findViewById(R.id.textView11);
        i1=getIntent();
        if((i1.getStringExtra(Intent.EXTRA_PACKAGE_NAME)).equals("login")) {
            Log.d("home", i1.getStringExtra(Intent.EXTRA_TEXT));
            //user=db.getUser(i1.getStringExtra(Intent.EXTRA_TEXT));
            //t11.setText(i1.getStringExtra(Intent.EXTRA_TEXT));
            t9.setText(i1.getStringExtra(Intent.EXTRA_TEXT));
            t10.setText(i1.getStringExtra(Intent.EXTRA_KEY_EVENT));
            t11.setText(i1.getStringExtra(Intent.EXTRA_REFERRER_NAME));
            user=new User(t9.getText().toString(),t11.getText().toString(),t10.getText().toString(),i1.getStringExtra(Intent.EXTRA_REFERRER_NAME));
        }
        else
        {
            t9.setText(i1.getStringExtra(Intent.EXTRA_TEXT));
            t10.setText(i1.getStringExtra(Intent.EXTRA_REFERRER));
            t11.setText(i1.getStringExtra(Intent.EXTRA_KEY_EVENT));
            user=new User(t9.getText().toString(),t11.getText().toString(),t10.getText().toString(),i1.getStringExtra(Intent.EXTRA_REFERRER_NAME));
            db.addUser(user);
        }

    }
    public boolean onCreateOptionsMenu(Menu menu1)
    {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu1);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.d_c : {
                Intent i = new Intent(this, chart.class);
                startActivity(i);
                break;
            }
            case R.id.logout : {
                final Intent i = new Intent(this, login.class);
                adb=new AlertDialog.Builder(this);
                adb.setCancelable(true);
                adb.setMessage("Do you really want to Logout from this account?");
                final AlertDialog.Builder enter = adb.setPositiveButton("enter", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int j) {
                        startActivity(i);
                        finish();
                    }
                });
                final AlertDialog.Builder cancel = adb.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                adb.create();
                adb.show();
                break;
            }
            case R.id.edit :{
                Intent i=new Intent(this,edit.class);
                i.putExtra(Intent.EXTRA_TEXT,t9.getText().toString());
                i.putExtra(Intent.EXTRA_REFERRER_NAME,i1.getStringExtra(Intent.EXTRA_REFERRER));
                i.putExtra(Intent.EXTRA_REFERRER,t10.getText().toString());
                i.putExtra(Intent.EXTRA_COMPONENT_NAME,t11.getText().toString());
                startActivityForResult(i,19);
                break;
            }
            case R.id.friend :{
                Intent i=new Intent(this,friendinfo.class);
                i.putExtra(Intent.EXTRA_TEXT,t9.getText().toString());
                i.putExtra(Intent.EXTRA_REFERRER,t10.getText().toString());
                i.putExtra(Intent.EXTRA_REFERRER_NAME,t11.getText().toString());
                i.putExtra(Intent.EXTRA_KEY_EVENT,user.get_password());
                startActivity(i);
                break;
            }
            default:
                throw new IllegalStateException("Unexpected value: " + item.getItemId());
        }
        return super.onOptionsItemSelected(item);
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    protected void onActivityResult(int requestcode, int resultcode, Intent data){
        super.onActivityResult(requestcode,resultcode,data);
            t9.setText(data.getStringExtra(Intent.EXTRA_TEXT));
            t10.setText(data.getStringExtra(Intent.EXTRA_REFERRER));
            t11.setText(data.getStringExtra(Intent.EXTRA_COMPONENT_NAME));
            db.updateUser(t9.getText().toString(),Intent.EXTRA_REFERRER_NAME,t10.getText().toString(),t11.getText().toString());
            Toast.makeText(this,"updated successfully",Toast.LENGTH_SHORT).show();
    }
}


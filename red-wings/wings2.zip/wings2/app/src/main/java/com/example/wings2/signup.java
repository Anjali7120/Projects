package com.example.wings2;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class signup extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Button b;
    Spinner s;
    EditText e2,e4,e5,e6,e7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        s=(Spinner)findViewById(R.id.spinner2);
        s.setOnItemSelectedListener(this);
        b=findViewById(R.id.button);
        e2=findViewById(R.id.editText2);
        e4=findViewById(R.id.editText4);
        e5=findViewById(R.id.editText5);
        e6=findViewById(R.id.editText6);
        e7=findViewById(R.id.editText7);
        b.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
       if((e4.getText().toString()).equals(e5.getText().toString())) {
           Intent i = new Intent(this, home.class);
           i.putExtra(Intent.EXTRA_TEXT, e2.getText().toString());
           i.putExtra(Intent.EXTRA_REFERRER_NAME, e4.getText().toString());
           i.putExtra(Intent.EXTRA_REFERRER, e6.getText().toString());
           i.putExtra(Intent.EXTRA_KEY_EVENT, e7.getText().toString());
           i.putExtra(Intent.EXTRA_PACKAGE_NAME, "signup");
           startActivity(i);
           finish();
       }
       else
       {
           Toast.makeText(this,"Password and Confirm password must be same",Toast.LENGTH_SHORT).show();
       }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        e6.setText(((TextView)view).getText());
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}


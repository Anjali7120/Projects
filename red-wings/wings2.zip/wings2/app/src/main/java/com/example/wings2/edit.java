package com.example.wings2;



import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class edit extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    EditText e8,e9,e10,e11;
    Spinner s;
    Button b3;
    AlertDialog.Builder adb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        s=(Spinner)findViewById(R.id.spinner);
        b3=findViewById(R.id.button3);
        e8=findViewById(R.id.editText8);
        e9=findViewById(R.id.editText9);
        e10=findViewById(R.id.editText10);
        e11=findViewById(R.id.editText11);
        s.setOnItemSelectedListener(this);
        Intent i=getIntent();
        e8.setText(i.getStringExtra(Intent.EXTRA_TEXT));
        e9.setText(i.getStringExtra(Intent.EXTRA_REFERRER_NAME));
        e10.setText(i.getStringExtra(Intent.EXTRA_REFERRER));
        e11.setText(i.getStringExtra(Intent.EXTRA_COMPONENT_NAME));
        b3.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        final Intent i1=new Intent();
        adb=new AlertDialog.Builder(this);
        adb.setCancelable(true);
        adb.setMessage("Do you want to save the changes?");
        final AlertDialog.Builder enter = adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int j) {
                i1.putExtra(Intent.EXTRA_TEXT,e8.getText().toString());
                i1.putExtra(Intent.EXTRA_REFERRER_NAME,e9.getText().toString());
                i1.putExtra(Intent.EXTRA_REFERRER,e10.getText().toString());
                i1.putExtra(Intent.EXTRA_COMPONENT_NAME,e11.getText().toString());
                setResult(20,i1);
                finish();
            }
        });
        final AlertDialog.Builder cancel = adb.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        adb.create();
        adb.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        e10.setText(((TextView)view).getText());
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}

